function [] = hw1_111598066_p4(file_name)
    RGB = imread(file_name);   % 讀取圖片
    I = rgb2gray(RGB);    % 轉灰階
    O=I;
    [height, width] = size(I);   % 取得大小
    list = 0:255;   % 建立灰階值

    for k=1:256   % 初始化
        list(k)=0;
    end

    cdf=list;

    for k=1:height   % 計算出現次數
        for j=1:width
            index=I(k,j)+1;   % 取得灰階值
            getnum=list(index);
            list(index)=getnum+1;
        end
    end

    for k=1:256   % cdf建立
        if k==1
            cdf(1)=list(1);
        else
            cdf(k)=cdf(k-1)+list(k);
        end
    end

    getmin=0;
    start=1;

    while(getmin>0)   % 找出cdf(min)
        if cdf(start)>0
            getmin=cdf(start);
        end
        start=start+1;
    end

    for k=1:height   % histogram
        for j=1:width
             O(k,j)=((cdf(I(k,j)+1)-getmin)/(height*width)*255);
        end
    end

    figure('Name','Histogram Equalization on Grayscale Image')
    subplot(2, 2, 1); imshow(I); title('Original Image(grayscale)');
    subplot(2, 2, 2); imhist(I, 32);
    subplot(2, 2, 3); imshow(O); title('Histogram Image');
    subplot(2, 2, 4); imhist(O, 32);
end

