function[] = hw1_111598066_p3(file_name, select)
    input_array = csvread(file_name);
    fromatInput = 'BW = %dx%d\n';
    input_size = size(input_array);
    fprintf(fromatInput,input_size(1),input_size(2));
    disp(input_array);

    if(select == 4)
        temp_array = input_array.';
        four_connected = bwlabel(temp_array, 4).';
        fromatInput = 'R = %dx%d\n';
        fprintf(fromatInput,input_size(1),input_size(2));
        disp(four_connected);
    elseif(select == 8)
        temp_array = input_array.';
        eight_connected = bwlabel(temp_array, 8).';
        fromatInput = 'R = %dx%d\n';
        fprintf(fromatInput,input_size(1),input_size(2));
        disp(eight_connected);
    else
        disp('Input_Error！');
    end
end